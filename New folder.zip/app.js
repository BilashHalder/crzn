require('dotenv').config();
const express = require("express");
const fileUpload = require('express-fileupload');
const cors = require('cors');
const app = express();

const CustomerRouter=require('./api/customer/customer.route');


/***********************************
 *       All Middlewares
 **********************************/

app.use(cors());
app.use(express.json());
app.use(fileUpload());

/************************************/
app.use("/api/customer",CustomerRouter);



app.get("/", (request, response) => {
    response.send("API Documentation");
});


app.post("/test", (request, response) => {

    console.log(request.body);
    console.log(request.files.doc);
        // console.log(request.query.id)
        // console.log(request.params.id)



        response.status(200).json({
        message: "Connection Established"
    });
});



/****************************************
 * To handle all invalid request
 * **************************************/

app.all("*", (request, response) => {
    response.status(500).json({
        message: "invalid request"
    });
});



/*Server Initilization */
app.listen(9000,()=>{
    console.log(`Api Server Running on Port No : 9000`);
});



