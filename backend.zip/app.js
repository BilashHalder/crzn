require('dotenv').config();
const express = require("express");
const fileUpload = require('express-fileupload');
const cors = require('cors');
const app = express();
const fs=require('fs');

const CustomerRouter=require('./api/customer/customer.route');
const AssociateRouter=require('./api/associate/associate.route');
const EmployeeRouter=require('./api/employee/employee.route');


/***********************************
 *       All Middlewares
 **********************************/

app.use(cors());
app.use(express.json());
app.use(fileUpload());

/********************
 * To serve all files
 ********************/

 app.get('/uploads/images/:id',(req, res)=>{
    id=req.params.id;
    if(fs.existsSync(`${__dirname}/uploads/images/${id}`))
     res.sendFile(`${__dirname}/uploads/images/${id}`);
     else
     res.send('invalid');
});






/***************Api Routings*********************/
app.use("/api/customer",CustomerRouter);
app.use("/api/associate",AssociateRouter);
app.use("/api/employee",EmployeeRouter);


/***************Deafult Routings*********************/
app.get("/", (request, response) => {
    response.send("API Documentation");
});


app.post("/test", (request, response) => {

    console.log(request.body);
    console.log(request.files.doc);
        // console.log(request.query.id)
        // console.log(request.params.id)



        response.status(200).json({
        message: "Connection Established"
    });
});



/****************************************
 * To handle all invalid request
 * **************************************/

app.all("*", (request, response) => {
    response.status(500).json({
        message: "invalid request"
    });
});



/*Server Initilization */
app.listen(9000,()=>{
    console.log(`Api Server Running on Port No : 9000`);
});



