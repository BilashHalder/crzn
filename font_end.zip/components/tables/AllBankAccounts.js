import { Button, Typography } from '@mui/material';
import {React,useState,useEffect} from 'react'
const axios = require("axios");
import Grid from "@mui/material/Unstable_Grid2";
import Divider from '@mui/material/Divider';
import DataTable from 'react-data-table-component';
import EditIcon from '@mui/icons-material/Edit';
import VisibilityIcon from '@mui/icons-material/Visibility';
import DeleteIcon from '@mui/icons-material/Delete';
import {IconButton,Modal,Box} from '@mui/material';
import { Stack } from '@mui/material';
import EditBank from '../forms/edit/EditBank';
import ViewBankInfo from '../view/ViewBankInfo';
const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: '90%',
    bgcolor: 'background.paper',
    border: '1px solid #000',
    boxShadow: 24,
    p: 4,
  };

  const style2 = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: '20%',
    bgcolor: 'background.paper',
    border: '1px solid #000',
    boxShadow: 24,
    p: 4,
  };




export default function AllBankAccounts() {
    const columns = [
        {
            name: 'Id',
            selector: row => row.id,
            center:true,
            sortable:true,
    
        },
        {
            name: 'Account No',
            selector: row => row.account_no,
            center:true,
            sortable:true,
        },
        {
            name: 'Ifsc Code',
            selector: row => row.ifsc_code,
            center:true,
            sortable:true,
        },
        {
            name: 'Bank Name',
            selector: row => row.bank,
            center:true,
            sortable:true,
        },
        {
            name: 'User Id',
            selector: row =>row.user_id,
            center:true,
            sortable:true,
        },
        {
            name: 'User Type',
            selector: row => row.user_type==1?'Customer':row.user_type==2?'Associate':'Employee',
            center:true,
            sortable:true,
        },
        {
            cell:(row)=>
           <div>
             <IconButton aria-label="edit" color="warning"  size="small" onClick={()=>{
                editData(row);
            }}>
            <EditIcon />
          </IconButton>

             <IconButton aria-label="edit" color="primary"  size="small" onClick={()=>{
                viewData(row);
            }}>
            <VisibilityIcon />
          </IconButton>
           </div>
        },
    ];

   
    const [data, setData] = useState([]);
    const [modify, setModify] = useState(null);
    const [update, setUpdate] = useState();
    const [deleteID, setdeleteID] = useState(null)
    const upDateState=()=>{
      axios.get('http://localhost:5000/api/account')
      .then(function (response) {
       setData(response.data);
      })
      .catch(function (error) {
        console.log(error);
      });
    }
    const exportTable=()=>{
        downloadCSV(data);
    }
    const editData=(data)=>{
       setModify(data);
        handleOpen();
        }
    const viewData=(data)=>{
        handleOpen1(data);
    }
    const deleteData=(data)=>{
        handleOpen2(data);
    }

    function convertArrayOfObjectsToCSV(array) {
        	let result;
        
        	const columnDelimiter = ',';
        	const lineDelimiter = '\n';
        	const keys = Object.keys(data[0]);
        
        	result = '';
        	result += keys.join(columnDelimiter);
        	result += lineDelimiter;
        
        	array.forEach(item => {
        		let ctr = 0;
        		keys.forEach(key => {
        			if (ctr > 0) result += columnDelimiter;
        
        			result += item[key];
        			
        			ctr++;
        		});
        		result += lineDelimiter;
        	});
        
        	return result;
        }

const recordDelete=(id)=>{
console.log(id);
axios.delete('http://localhost:5000/api/salary/'+id)
      .then(function (response) {
       console.log(response);
       handleClose2();
      })
      .catch(function (error) {
        console.log(error);
      });

upDateState();

}
    function downloadCSV(array) {
        	const link = document.createElement('a');
        	let csv = convertArrayOfObjectsToCSV(array);
        	if (csv == null) return;
        	const filename = 'banK_accounts_all.csv';
        	if (!csv.match(/^data:text\/csv/i)) {
        		csv = `data:text/csv;charset=utf-8,${csv}`;
        	}
        
        	link.setAttribute('href', encodeURI(csv));
        	link.setAttribute('download', filename);
        	link.click();
        }


        const [open, setOpen] = useState(false);
        const handleOpen = () => setOpen(true);
        const handleClose = () => {
          setOpen(false);
          upDateState();

        };



        const [open1, setOpen1] = useState(false);
        const handleOpen1 = (data) => {
          setOpen1(true);
          setModify(data);

        }
        const handleClose1 = () => setOpen1(false);

        const [open2, setOpen2] = useState(false);
        const handleOpen2 = (data) => {
          setOpen2(true);
          setdeleteID(data.id);
        
        };
        const handleClose2 = () => setOpen2(false);


    useEffect(() => {
        axios.get('http://localhost:5000/api/account')
        .then(function (response) {
         setData(response.data);
         console.log(response.data)
        })
        .catch(function (error) {
          console.log(error);
        })
    }, [])
    
  return (
    <div>

<Grid container spacing={2}>
<Grid md={10} sx={{'textAlign':'center'}}>
<h2>All Bank Accounts</h2>
<Divider></Divider> 
</Grid> 
<Grid md={2} sx={{'textAlign':'right','marginY':'2%'}}>
<Button onClick={exportTable} variant="outlined">Export CSV</Button>
</Grid>
 
</Grid>
        
        
        <DataTable
            columns={columns}
            data={data}
            pagination
            responsive={true}
            defaultSortAsc={true}
           
            highlightOnHover={true}
            fixedHeader={true}
            fixedHeaderScrollHeight={'500px'}

        />

<Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          
          <EditBank data={modify} fun={handleClose}/>
          
        </Box>
      </Modal>



      <Modal
        open={open1}
        onClose={handleClose1}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
         <ViewBankInfo data={modify} fun={handleClose1}></ViewBankInfo>
        </Box>

      </Modal>

      <Modal
        open={open2}
        onClose={handleClose2}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style2}>
        <Typography variant="p" component="p" style={{'color':'red'}}>  Are You Sure to Delete This Record?</Typography>
        <Stack direction="row" spacing={2} sx={{'marginY':'6%'}}>
            <Button variant="outlined" color="error" onClick={()=>{
              recordDelete(deleteID);
            }}>Yes</Button>
            <Button variant="outlined" onClick={()=>{
              handleClose2();

            }}>No</Button>
        </Stack>
        </Box>
      </Modal>

    </div>
  )
}
