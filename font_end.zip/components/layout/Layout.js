import React from 'react'

export default function Layout() {
  return (
    <div>Layout</div>
  )
}
