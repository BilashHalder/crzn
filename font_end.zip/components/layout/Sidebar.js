import React from 'react'

export default function Sidebar() {
  return (
    <div>Sidebar</div>
  )
}
