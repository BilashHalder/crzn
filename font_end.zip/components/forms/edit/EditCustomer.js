import { React, useState, useEffect } from "react";
import Grid from "@mui/material/Unstable_Grid2";
import { Box, TextField, Paper, Select,
  MenuItem,IconButton,Button } from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import axios from "axios";

import PhotoCamera from "@mui/icons-material/PhotoCamera";
export default function EditCustomer(props) {
  const [data, setData] = useState(null);


  const formHandler = () => {
    e.preventDefault();
  };

  useEffect(() => {
    axios
      .get(`http://localhost:9000/api/customer/${props.id}`)
      .then(function (response) {
        setData(response.data);
      })
      .catch(function (error) {
        console.log(error);
      });
  }, []);

  return (
    <div>
      {data ? (
        <Box sx={{ flexGrow: 1 }} component="form" onSubmit={formHandler}>
          <Grid container spacing={2}>
            <Grid md={4}>
              <TextField
                name="name"
                label="Name"
                type="text"
                InputLabelProps={{ shrink: true }}
                fullWidth
                value={data.name}
              />
            </Grid>

            <Grid md={4}>
              <TextField
                name="email"
                label="Email"
                type="email"
                InputLabelProps={{ shrink: true }}
                fullWidth
                value={data.email}
              />
            </Grid>

            <Grid md={4}>
              <TextField
                name="phone"
                label="Phone No"
                type="number"
                InputLabelProps={{ shrink: true }}
                fullWidth
                value={data.phone}
              />
            </Grid>

            <Grid xs={6} md={4} lg={4}>
                <TextField
                  name="referred_by"
                  label="Referrel Code"
                  type="text"
                  InputLabelProps={{ shrink: true }}
                  fullWidth
                  value={data.referred_by}
                />
              </Grid>

              <Grid xs={6} md={4} lg={4}>
                <Select
                  value={data.gender}
                  label="Gender"
                 
                  fullWidth
                >
                  <MenuItem value={0}>Select Gender</MenuItem>
                  <MenuItem value={1}>Male</MenuItem>
                  <MenuItem value={2}>Female</MenuItem>
                  <MenuItem value={3}>Others</MenuItem>
                </Select>
              </Grid>

              <Grid xs={6} md={4} lg={4}>
                <Select
                  value={data.status}
                  label="Status"
                 
                  fullWidth
                >
                  <MenuItem value={0}>Select Status</MenuItem>
                  <MenuItem value={1}>Active</MenuItem>
                  <MenuItem value={2}>Deacitve</MenuItem>
                </Select>
              </Grid>


              <Grid xs={6} md={4} lg={4}>
                <img src={`http://localhost:9000/uploads/images/${data.image}`} height={100} width={100}/>
                <IconButton
                  color="success"
                  aria-label="upload picture"
                  component="label"
                >
                  <input hidden type="file" accept="image/*"  />
                  <PhotoCamera />
                </IconButton>
              </Grid>

              <Grid xs={6} md={4} lg={4} sx={{'marginTop':'2%'}}>
              <Button variant="outlined" color="warning" type="submit">
              Update & Save
            </Button>
              </Grid>



          </Grid>
        </Box>
      ) : (
        <p>Please Wait..</p>
      )}
    </div>
  );
}
