import { React, useState } from "react";
import Grid from "@mui/material/Unstable_Grid2";
import Box from "@mui/material/Box";
import CloseIcon from "@mui/icons-material/Close";
const axios = require("axios");
import { Alert, Snackbar, Button, TextField } from "@mui/material";

export default function EditBank(props) {
  let { id, account_no, ifsc_code, bank, user_id, user_type, status } =
    props.data;
  const [update_account_no, setAccount] = useState(account_no);
  const [update_ifsc_code, setIfsc] = useState(ifsc_code);
  const [update_bank,setBank] = useState(bank);
const [response, setResponse] = useState('')
  const [open, setOpen] = useState(false);
  const [color, setColor] = useState("info");

  const formHandler = (e) => {
    let account_no=update_account_no;
    let bank=update_bank;
    let ifsc_code=update_ifsc_code


    e.preventDefault();

    axios
      .put("http://localhost:5000/api/account/"+id, {
        id, account_no, ifsc_code, bank, user_id, user_type, status
      })
      .then((response) => {
        setResponse("Data Updated Successfully!");
        setColor("warning"); //error
        setOpen(true);
      })
      .catch((error) => {
        console.log(error)
        setResponse("Please Try Again Later!");
        setColor("error"); //error
        setOpen(true);
      });
  };
  const account_noHandler = (e) => {
    setAccount(e.target.value);
  };
  const ifsc_codeHandler = (e) => {
    setIfsc(e.target.value);
  };
  const bankHandler = (e) => {
    setBank(e.target.value);
  };

  const handleClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpen(false);
  };
  return (
    <div>
      <Box sx={{ flexGrow: 1 }} component="form" onSubmit={formHandler}>
        <h2 style={{ textAlign: "center" }}>Edit Bank Account Information</h2>

        <Grid container spacing={2}>
          <Grid md={4}>
            <TextField
              name="account_no"
              label="Account No"
              type="text"
              InputLabelProps={{ shrink: true }}
              fullWidth
              value={update_account_no}
              onChange={account_noHandler}
            />
          </Grid>
          <Grid md={4}>
            <TextField
              name="ifsc_code"
              label="Ifsc Code"
              type="text"
              InputLabelProps={{ shrink: true }}
              fullWidth
              value={update_ifsc_code}
              onChange={ifsc_codeHandler}
            />
          </Grid>
          <Grid md={4}>
            <TextField
              name="bank"
              label="Bank Name"
              type="text"
              InputLabelProps={{ shrink: true }}
              fullWidth
              value={update_bank}
              onChange={bankHandler}
            />
          </Grid>

          <Grid md={3}></Grid>
          <Grid md={3}>
            <Button
              variant="outlined"
              sx={{ textAlign: "center" }}
              color="success"
              type="submit"
            >
              Update & Save
            </Button>
            <Button
              sx={{ marginLeft: "10%" }}
              variant="outlined"
              color="error"
              startIcon={<CloseIcon />}
              onClick={() => {
                props.fun();
              }}
            >
              Close
            </Button>
          </Grid>
          <Grid md={3}>
            <Snackbar open={open} onClose={handleClose} autoHideDuration={2000}>
              <Alert severity={color}>{response}</Alert>
            </Snackbar>
          </Grid>
        </Grid>
      </Box>
    </div>
  );
}
