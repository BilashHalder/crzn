import React from 'react'

export default function Leave() {
  return (
    <div>Leave</div>
  )
}
