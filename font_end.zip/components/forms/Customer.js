import { React, useState } from "react";
import axios from 'axios';
import Grid from "@mui/material/Unstable_Grid2";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import {
  Alert,
  Snackbar,
  Button,
  Divider,
  TextField,
  TableContainer,
  Select,
  MenuItem,
} from "@mui/material";

import IconButton from "@mui/material/IconButton";
import PhotoCamera from "@mui/icons-material/PhotoCamera";

export default function Customer() {
  const [name, setName] = useState();
  const [email, setEmail] = useState();
  const [phone, setPhone] = useState();
  const [referred_by, setRefer] = useState();
  const [image, setImage] = useState();
  const [gender, setGender] = useState(0);

  const [response, setResponse] = useState("no response");
  const [open, setOpen] = useState(false);
  const [color, setColor] = useState("info");

  const resetForm = () => {
    setName("");
    setEmail("");
    setPhone("");
    setRefer("");
    setImage("");
    setGender(0);
  };
  const formHandler = (e) => {
    e.preventDefault();
    let formData = new FormData();
    formData.append("image", image);
    formData.append("name", name);
  
    let data=new FormData();
    data.append('name',name);
    data.append('gender',gender);
    data.append('phone',phone);
    data.append('email',email);
    data.append('referred_by',referred_by);
    data.append('image', image);
    axios({
      method: "post",
      url: "http://localhost:9000/api/customer",
      data: data,
      headers: { "Content-Type": "multipart/form-data" },
    })
      .then( (response)=> {
        setResponse(response.data.message);
        setColor("success"); 
        setOpen(true);
        resetForm();
      })
      .catch( (response)=> {
        setResponse(response.response.data.message);
        setColor("error");
        setOpen(true);
      });

   
  };

  const nameHandler = (e) => {
    setName(e.target.value);
  };
  const emailHandler = (e) => {
    setEmail(e.target.value);
  };

  const phoneHandler = (e) => {
    setPhone(e.target.value);
  };
  const referelHandler = (e) => {
    setRefer(e.target.value);
  };

  const imageHandler = (e) => {
    if (e.target.files && e.target.files[0]){
      setImage(e.target.files[0])
    }
  };
  const genderHandler = (e) => {
    setGender(e.target.value);
  };

  const handleClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpen(false);
  };
  return (
    <div>
      <Box sx={{ flexGrow: 1 }} component="form" onSubmit={formHandler}>
        <h2 style={{ textAlign: "center" }}>Add New Customer</h2>
        <Grid container spacing={2}>
          <Grid md={12}>
            <Grid container spacing={2}>
              <Grid xs={6} md={6} lg={6}>
                <TextField
                  name="name"
                  label="Name"
                  type="text"
                  InputLabelProps={{ shrink: true }}
                  fullWidth
                  value={name}
                  onChange={nameHandler}
                />
              </Grid>
              <Grid xs={6} md={6} lg={6}>
                <TextField
                  name="email"
                  label="Email"
                  type="email"
                  InputLabelProps={{ shrink: true }}
                  fullWidth
                  value={email}
                  onChange={emailHandler}
                />
              </Grid>
              <Grid xs={6} md={4} lg={4}>
                <TextField
                  name="phone"
                  label="Phone No"
                  type="number"
                  InputLabelProps={{ shrink: true }}
                  fullWidth
                  value={phone}
                  onChange={phoneHandler}
                />
              </Grid>
              <Grid xs={6} md={4} lg={4}>
                <TextField
                  name="referred_by"
                  label="Referrel Code"
                  type="text"
                  InputLabelProps={{ shrink: true }}
                  fullWidth
                  value={referred_by}
                  onChange={referelHandler}
                />
              </Grid>
              <Grid xs={6} md={4} lg={4}>
                <Select
                  value={gender}
                  label="Gender"
                  onChange={genderHandler}
                  fullWidth
                >
                  <MenuItem value={0}>Select Gender</MenuItem>
                  <MenuItem value={1}>Male</MenuItem>
                  <MenuItem value={2}>Female</MenuItem>
                  <MenuItem value={3}>Others</MenuItem>
                </Select>
              </Grid>
              <Grid xs={6} md={4} lg={4}>
                <IconButton
                  color="success"
                  aria-label="upload picture"
                  component="label"
                >
                  <input hidden type="file" accept="image/*" onChange={imageHandler} />
                  <PhotoCamera />
                </IconButton>
                  {
                  image?<img src={URL.createObjectURL(image)} height={100} width={100}/>:''
                  }
                
              </Grid>
            </Grid>

            <Divider sx={{ marginY: "3%" }} />
            <Button variant="outlined" color="success" type="submit">
              Save
            </Button>

            <Snackbar open={open} onClose={handleClose} autoHideDuration={2000}>
              <Alert severity={color}>{response}</Alert>
            </Snackbar>
          </Grid>

          <Grid md={4}>
            <TableContainer component={Paper}></TableContainer>
          </Grid>
        </Grid>
      </Box>
    </div>
  );
}

