import {React,useState,useEffect} from 'react'

export default function ViewAccounts(props) {
    let {user_id,user_type}=props.data;
    const [data] = useState([]);

    
  return (
    <div>
        {
            data.length<1?<p>No Account Added Yet!</p>:
            <table>

            
            </table>
        }
    </div>
  )
}
