import React from 'react'
import ViewAccounts from './ViewAccounts';

export default function ViewBankInfo(props) {
    let { id, account_no, ifsc_code, bank, user_id, user_type, status } =
    props.data;
  return (
    <div>
        <p>User Information</p>
        <p>All Bank Accounts</p>
        <ViewAccounts data={props.data}/>
    </div>
  )
}
