import React from 'react'

export default function CustomerView(props) {
  return (
    <div>CustomerView {props.id}</div>
  )
}
