import React from 'react'

export default function Nominee() {
  return (
    <div>Nominee</div>
  )
}
