import React from 'react'

export default function Employee() {
  return (
    <div>Employee</div>
  )
}
