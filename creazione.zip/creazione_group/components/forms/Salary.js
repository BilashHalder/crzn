import { React, useState } from "react";
import Grid from "@mui/material/Unstable_Grid2";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import {
  Alert,
  Snackbar,
  Button,
  Divider,
  TextField,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow
} from "@mui/material";
const axios = require("axios");

export default function Salary() {
  const [basic, setBasic] = useState();
  const [hra, setHra] = useState();
  const [conveyance, setConveyance] = useState();
  const [medical, setMedical] = useState();
  const [special, setSpecial] = useState();
  const [pf, setPf] = useState();
  const [insurance, setInsurance] = useState();
  const [tax, setTax] = useState();
  const [total, setTotal] = useState();

  const [response, setResponse] = useState("no response");
  const [open, setOpen] = useState(false);
  const [color, setColor] = useState("info");

  const resetForm = () => {
    setBasic(0);
    setHra(0);
    setConveyance(0);
    setMedical(0);
    setSpecial(0);
    setPf(0);
    setInsurance(0);
    setTax(0);
    setTotal(0);
  };
  const formHandler = (e) => {
    e.preventDefault();

    axios
      .post("http://localhost:5000/api/salary", {
        basic,
        hra,
        conveyance,
        special,
        medical,
        pf,
        insurance,
        tax,
      })
      .then((response) => {
        setResponse("Data Saved Successfully!");
        setColor("success"); //error
        setOpen(true);
        resetForm();
      })
      .catch((error) => {
        setResponse("Please Try Again Later!");
        setColor("error"); //error
        setOpen(true);
      });
  };
  const basicHandler = (e) => {
    e.target.value < 0 ? setBasic(1) : setBasic(parseFloat(e.target.value));
    taxHandler();
  };
  const hraHandler = (e) => {
    e.target.value < 0 ? setHra(1) : setHra(parseFloat(e.target.value));
    taxHandler();
  };
  const conveyanceHandler = (e) => {
    e.target.value < 0
      ? setConveyance(1)
      : setConveyance(parseFloat(e.target.value));
    taxHandler();
  };
  const medicalHandler = (e) => {
    e.target.value < 0 ? setMedical(1) : setMedical(parseFloat(e.target.value));
    taxHandler();
  };

  const specialHandler = (e) => {
    e.target.value < 0 ? setSpecial(1) : setSpecial(parseFloat(e.target.value));
    taxHandler();
  };
  const pfHandler = (e) => {
    e.target.value < 0 ? setPf(1) : setPf(parseFloat(e.target.value));
    taxHandler();
  };
  const insuranceHandler = (e) => {
    e.target.value < 0
      ? setInsurance(1)
      : setInsurance(parseFloat(e.target.value));
    taxHandler();
  };
  const taxHandler = () => {
    let total = basic + hra + conveyance + medical + special + insurance + pf;
    if (total < 20000) {
      setTax(0);
      setTotal(basic + hra + conveyance + medical + special - (insurance + pf));
    } else if (total < 42000) {
      setTax(total * 0.9);
      setTotal(
        basic +
          hra +
          conveyance +
          medical +
          special -
          (insurance + pf + total * 0.9)
      );
    } else {
      setTax(total * 1.4);
      setTotal(
        basic +
          hra +
          conveyance +
          medical +
          special -
          (insurance + pf + total * 1.4)
      );
    }
  };
  const handleClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpen(false);
  };
  return (
    <div>
      <Box sx={{ flexGrow: 1 }} component="form" onSubmit={formHandler}>
        <h2 style={{ textAlign: "center" }}>Add New Salary Information</h2>
        <Grid container spacing={2}>
          <Grid md={8}>
            <Grid container spacing={2}>
              <Grid xs={6} md={4} lg={4}>
                <TextField
                  name="basic"
                  label="Basic"
                  type="number"
                  InputLabelProps={{ shrink: true }}
                  fullWidth
                  value={basic}
                  onChange={basicHandler}
                />
              </Grid>
              <Grid xs={6} md={4} lg={4}>
                <TextField
                  name="hra"
                  label="HRA"
                  type="number"
                  InputLabelProps={{ shrink: true }}
                  fullWidth
                  value={hra}
                  onChange={hraHandler}
                />
              </Grid>
              <Grid xs={6} md={4} lg={4}>
                <TextField
                  name="conveyance"
                  label="Conveyance"
                  type="number"
                  InputLabelProps={{ shrink: true }}
                  fullWidth
                  value={conveyance}
                  onChange={conveyanceHandler}
                />
              </Grid>
              <Grid xs={6} md={4} lg={4}>
                <TextField
                  name="medical"
                  label="Medical"
                  type="number"
                  InputLabelProps={{ shrink: true }}
                  fullWidth
                  value={medical}
                  onChange={medicalHandler}
                />
              </Grid>
              <Grid xs={6} md={4} lg={4}>
                <TextField
                  name="special"
                  label="Special"
                  type="number"
                  InputLabelProps={{ shrink: true }}
                  fullWidth
                  value={special}
                  onChange={specialHandler}
                />
              </Grid>
              <Grid xs={6} md={4} lg={4}>
                <TextField
                  name="pf"
                  label="PF"
                  type="number"
                  InputLabelProps={{ shrink: true }}
                  fullWidth
                  value={pf}
                  onChange={pfHandler}
                />
              </Grid>
              <Grid xs={6} md={4} lg={4}>
                <TextField
                  name="insurance"
                  label="Insurance"
                  type="number"
                  InputLabelProps={{ shrink: true }}
                  fullWidth
                  value={insurance}
                  onChange={insuranceHandler}
                />
              </Grid>
              <Grid xs={6} md={4} lg={4}>
                <TextField
                  name="tax"
                  label="Tax"
                  type="number"
                  min="0"
                  InputLabelProps={{ shrink: true }}
                  fullWidth
                  value={tax}
                  disabled
                />
              </Grid>
            </Grid>

            <Divider sx={{ marginY: "3%" }} />
            <Button variant="outlined" color="success" type="submit">
              Save
            </Button>

            <Snackbar open={open} onClose={handleClose} autoHideDuration={2000}>
              <Alert severity={color}>{response}</Alert>
            </Snackbar>
          </Grid>

          <Grid md={4}>
            <TableContainer component={Paper}>
              <Table aria-label="spanning table">
                <TableHead>
                  <TableRow>
                    <TableCell align="center" colSpan={1}>
                      Salary Details
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  <TableRow>
                    <TableCell>Basic</TableCell>
                    <TableCell align="right">{basic}</TableCell>
                    <TableCell>HRA</TableCell>
                    <TableCell align="right">{hra}</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>Conveyance</TableCell>
                    <TableCell align="right">{conveyance}</TableCell>
                    <TableCell>Medical</TableCell>
                    <TableCell align="right">{medical}</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>Special</TableCell>
                    <TableCell align="right">{special}</TableCell>

                    <TableCell>Insurance</TableCell>
                    <TableCell align="right">{insurance}</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell rowSpan={3} />
                    <TableCell colSpan={2}>Subtotal</TableCell>
                    <TableCell align="right">{total}</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell rowSpan={3} />
                    <TableCell colSpan={2}>PF</TableCell>
                    <TableCell align="right">{pf}</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>Tax</TableCell>
                    <TableCell align="right">{tax}</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell colSpan={2}>Total</TableCell>
                    <TableCell align="right">{total}</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
          </Grid>
        </Grid>
      </Box>
    </div>
  );
}
