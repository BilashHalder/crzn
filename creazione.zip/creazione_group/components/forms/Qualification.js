import React from 'react'

export default function Qualification() {
  return (
    <div>Qualification</div>
  )
}
