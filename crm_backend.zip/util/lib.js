const uploadImage=(img)=>{
return 'newfilename';
}

const uploadFile=(doc)=>{
    return 'newfilename';
}

const updateDocs=(doc,oldfile)=>{
    return 'newfilename';
}

const updateImage=(img,oldimg)=>{
    return 'newfilename';
}

const getId=(id,type)=>{

}


module.exports = { uploadImage, uploadFile, updateDocs, updateImage };


