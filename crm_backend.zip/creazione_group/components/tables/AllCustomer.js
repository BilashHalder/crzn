import React from 'react'

export default function AllCustomer() {
  return (
    <div>AllCustomer</div>
  )
}
