import * as React from 'react';
import{toWord} from '../../util/lib'
import {Table,Button} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';

const TAX_RATE = 0.07;

function ccyFormat(num) {
  return `${num.toFixed(2)}`;
}

function priceRow(qty, unit) {
  return qty * unit;
}

function createRow(desc, qty, unit) {
  const price = priceRow(qty, unit);
  return { desc, qty, unit, price };
}

function subtotal(items) {
  return items.map(({ price }) => price).reduce((sum, i) => sum + i, 0);
}

const rows = [
  createRow('Paperclips (Box)', 100, 1.15),
  createRow('Paper (Case)', 10, 45.99),
  createRow('Waste Basket', 2, 17.99),
];

const invoiceSubtotal = subtotal(rows);
const invoiceTaxes = TAX_RATE * invoiceSubtotal;
const invoiceTotal = invoiceTaxes + invoiceSubtotal;

export default function ViewSalary(props) {
    let {hra,basic,pf,tax,conveyance,medical,insurance,special}=props.data;
  return (
   <div>
     <Button  sx={{'marginLeft':'95%'}} variant="outlined"  startIcon={<CloseIcon/>} onClick={()=>{props.fun()}}></Button>

<TableContainer component={Paper}>
  <Table sx={{ minWidth: 700 }} aria-label="spanning table">
    <TableHead>
      <TableRow>
        <TableCell>Desc</TableCell>
        <TableCell align="right">Monthly</TableCell>
        <TableCell align="right">Total</TableCell>
      </TableRow>
    </TableHead>
    <TableBody>
    
        <TableRow >
          <TableCell>{'Basic'}</TableCell>
          <TableCell align="right">{'₹ '+basic}</TableCell>
          <TableCell align="right">{'₹ '+basic * 12}</TableCell>
        </TableRow>
        <TableRow >
          <TableCell>{'HRA'}</TableCell>
          <TableCell align="right">{'₹ '+hra}</TableCell>
          <TableCell align="right">{'₹ '+hra * 12}</TableCell>
        </TableRow>
        <TableRow >
          <TableCell>{'Conveyance'}</TableCell>
          <TableCell align="right">{'₹ '+conveyance}</TableCell>
          <TableCell align="right">{'₹ '+conveyance * 12}</TableCell>
        </TableRow>
        <TableRow >
          <TableCell>{'Special'}</TableCell>
          <TableCell align="right">{'₹ '+special}</TableCell>
          <TableCell align="right">{'₹ '+special * 12}</TableCell>
        </TableRow>
        <TableRow >
          <TableCell>{`Medical ₹ (${medical}) + Provident Fund ₹(${pf}) + Insurance ₹ (${insurance})`}</TableCell>
          <TableCell align="right">{'₹ '+(medical+pf+insurance)}</TableCell>
          <TableCell align="right">{'₹ '+(medical+pf+insurance) * 12}</TableCell>
        </TableRow>
      <TableRow>
        <TableCell rowSpan={3} />
        <TableCell colSpan={2}>Subtotal</TableCell>
        <TableCell align="right">{'₹ '+ (medical+pf+insurance+special+conveyance+hra+basic)}</TableCell>
      </TableRow>
      <TableRow>
        <TableCell>Tax</TableCell>
        <TableCell align="right">{`${(TAX_RATE * 100).toFixed(0)} %`}</TableCell>
        <TableCell align="right">{'₹ '+ tax}</TableCell>
      </TableRow>
      <TableRow>
        <TableCell>{`Medical ₹ (${medical}) + Provident Fund ₹(${pf}) + Insurance ₹ (${insurance})`}</TableCell>
        <TableCell align="right"></TableCell>
        <TableCell align="right">{'₹ '+ (medical+pf+insurance)}</TableCell>
      </TableRow>
      
      <TableRow>
        <TableCell colSpan={1}>Total</TableCell>
        <TableCell align="right">{`₹ ${(hra+basic+pf+conveyance+special+medical+insurance+special)-(medical+insurance+special+tax)} ${toWord((hra+basic+pf+conveyance+special+medical+insurance+special)-(medical+insurance+special+tax))} Only`}</TableCell>
      </TableRow>
    </TableBody>
  </Table>
  
</TableContainer>
   </div>
  );
}
