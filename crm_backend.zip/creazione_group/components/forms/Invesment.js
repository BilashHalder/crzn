import React from 'react'

export default function Invesment() {
  return (
    <div>Invesment</div>
  )
}
