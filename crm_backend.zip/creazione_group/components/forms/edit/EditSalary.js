import {React,useState} from 'react'
import Grid from "@mui/material/Unstable_Grid2";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import CloseIcon from '@mui/icons-material/Close';
const axios = require("axios");
import {
  IconButton,
  Alert,
  Snackbar,
  Button,
  Divider,
  TextField,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow
} from "@mui/material";




export default function EditSalary(props) {
  let data=props.data;
  const [basic, setBasic] = useState(data.basic);
  const [hra, setHra] = useState(data.hra);
  const [conveyance, setConveyance] = useState(data.conveyance);
  const [medical, setMedical] = useState(data.medical);
  const [special, setSpecial] = useState(data.special);
  const [pf, setPf] = useState(data.pf);
  const [insurance, setInsurance] = useState(data.insurance);
  const [tax, setTax] = useState(data.tax);
  const [id, setid] = useState(props.data.id);
  const [total, setTotal] = useState();

  const [response, setResponse] = useState("no response");
  const [open, setOpen] = useState(false);
  const [color, setColor] = useState("info");


  const formHandler = (e) => {
    e.preventDefault();

    axios
      .put("http://localhost:5000/api/salary/"+id, {
        basic,
        hra,
        conveyance,
        special,
        medical,
        pf,
        insurance,
        tax,
        id
      })
      .then((response) => {
        setResponse("Data Updated Successfully!");
        setColor("warning"); //error
        setOpen(true);
      })
      .catch((error) => {
        console.log(error)
        setResponse("Please Try Again Later!");
        setColor("error"); //error
        setOpen(true);
      });
  };
  const basicHandler = (e) => {
    e.target.value < 0 ? setBasic(1) : setBasic(parseFloat(e.target.value));
    taxHandler();
  };
  const hraHandler = (e) => {
    e.target.value < 0 ? setHra(1) : setHra(parseFloat(e.target.value));
    taxHandler();
  };
  const conveyanceHandler = (e) => {
    e.target.value < 0
      ? setConveyance(1)
      : setConveyance(parseFloat(e.target.value));
    taxHandler();
  };
  const medicalHandler = (e) => {
    e.target.value < 0 ? setMedical(1) : setMedical(parseFloat(e.target.value));
    taxHandler();
  };

  const specialHandler = (e) => {
    e.target.value < 0 ? setSpecial(1) : setSpecial(parseFloat(e.target.value));
    taxHandler();
  };
  const pfHandler = (e) => {
    e.target.value < 0 ? setPf(1) : setPf(parseFloat(e.target.value));
    taxHandler();
  };
  const insuranceHandler = (e) => {
    e.target.value < 0
      ? setInsurance(1)
      : setInsurance(parseFloat(e.target.value));
    taxHandler();
  };
  const taxHandler = () => {
    let total = basic + hra + conveyance + medical + special + insurance + pf;
    if (total < 20000) {
      setTax(0);
      setTotal(basic + hra + conveyance + medical + special - (insurance + pf));
    } else if (total < 42000) {
      setTax(total * 0.9);
      setTotal(
        basic +
          hra +
          conveyance +
          medical +
          special -
          (insurance + pf + total * 0.9)
      );
    } else {
      setTax(total * 1.4);
      setTotal(
        basic +
          hra +
          conveyance +
          medical +
          special -
          (insurance + pf + total * 1.4)
      );
    }
  };
  const handleClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpen(false);
  };
  return (
    <div>
      <Box sx={{ flexGrow: 1 }} component="form" onSubmit={formHandler}>
        <h2 style={{ textAlign: "center" }}>Edit Salary Information</h2>

        <Grid container spacing={2}>
        <Grid md={3}>
        <TextField
                  name="basic"
                  label="Basic"
                  type="number"
                  InputLabelProps={{ shrink: true }}
                  fullWidth
                  value={basic}
                  onChange={basicHandler}
                />
        </Grid>
        <Grid md={3}>
        <TextField
                  name="hra"
                  label="HRA"
                  type="number"
                  InputLabelProps={{ shrink: true }}
                  fullWidth
                  value={hra}
                  onChange={hraHandler}
                />
        </Grid>
        <Grid md={3}>
        <TextField
                  name="conveyance"
                  label="Conveyance"
                  type="number"
                  InputLabelProps={{ shrink: true }}
                  fullWidth
                  value={conveyance}
                  onChange={conveyanceHandler}
                />
        </Grid>
        <Grid md={3}>
        <TextField
                  name="medical"
                  label="Medical"
                  type="number"
                  InputLabelProps={{ shrink: true }}
                  fullWidth
                  value={medical}
                  onChange={medicalHandler}
                />
        </Grid>
        <Grid md={3}>
        <TextField
                  name="special"
                  label="Special"
                  type="number"
                  InputLabelProps={{ shrink: true }}
                  fullWidth
                  value={special}
                  onChange={specialHandler}
                />
        </Grid>
        <Grid md={3}>
        <TextField
                  name="pf"
                  label="PF"
                  type="number"
                  InputLabelProps={{ shrink: true }}
                  fullWidth
                  value={pf}
                  onChange={pfHandler}
                />
        </Grid>
        <Grid md={3}>
        <TextField
                  name="insurance"
                  label="Insurance"
                  type="number"
                  InputLabelProps={{ shrink: true }}
                  fullWidth
                  value={insurance}
                  onChange={insuranceHandler}
                />
        </Grid>
        <Grid md={3}>
        <TextField
                  name="tax"
                  label="Tax"
                  type="number"
                  min="0"
                  InputLabelProps={{ shrink: true }}
                  fullWidth
                  value={tax}
                  disabled
                />
        </Grid>
        <Grid md={3}>
          
        </Grid>
        <Grid md={3}>
           <Button variant="outlined" sx={{'textAlign':'center'}} color="success" type="submit">
              Update & Save
            </Button>
            <Button sx={{'marginLeft':'10%'}} variant="outlined" color="error" startIcon={<CloseIcon/>} onClick={()=>{props.fun()}}>Close</Button>

          
        </Grid>
        <Grid md={3}>
            <Snackbar open={open} onClose={handleClose} autoHideDuration={2000}>
              <Alert severity={color}>{response}</Alert>
            </Snackbar>
        </Grid>
        </Grid>
        </Box>
    </div>
  )
}
