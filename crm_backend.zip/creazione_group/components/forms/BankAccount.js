import React from 'react'

export default function BankAccount() {
  return (
    <div>BankAccount</div>
  )
}
