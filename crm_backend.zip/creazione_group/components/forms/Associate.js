import React from 'react'

export default function Associate() {
  return (
    <div>Associate</div>
  )
}
