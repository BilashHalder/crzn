require('dotenv').config();
const express=require("express");
const fileUpload = require('express-fileupload');
const cors = require('cors');
const app=express();
const bodyParser = require('body-parser');



const AdminRouter=require("./api/admin/admin.route");
const AssociateRouter=require("./api/associate/associate.route");
const SalaryRouter=require("./api/salary/salary.route");
const BankRouter=require('./api/account/account.route');
const CustomerRouter=require('./api//customer/customer.route');











/***********************************
 *       All Middlewares
 **********************************/
 app.use(cors());
 app.use(express.json());
 app.use(fileUpload());
// app.use(bodyParser.json());
// app.use(bodyParser.urlencoded({extended: true}));


/*************
 * 
 */

 app.use("/api/admin",AdminRouter);
 app.use("/api/associate",AssociateRouter);
 app.use("/api/salary",SalaryRouter);
 app.use("/api/account",BankRouter);
 app.use("/api/customer",CustomerRouter);



 app.get("/",(request,response)=>{
    response.send("API Documentation");
});



/****************************
 * To handle all invalid request
 * ***************************/

 app.all("*",(request,response)=>{
    response.status(500).json({
        message:"invalid request"
    });
    });


/*Server Initilization */
     app.listen(5000,()=>{
        console.log(`Api Server Running on Port No : 5000`);
    });


    